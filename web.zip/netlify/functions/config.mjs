import { getStore } from "@netlify/blobs";

export default async (req) => {
  const store = getStore("sanz");
  if (req.method === "GET") {
    const c = await store.get("config", { type: "json" });
    return Response.json(c || {}, { headers: { "cache-control": "no-store" } });
  }
  if (req.method === "PUT") {
    const pass = process.env.ADMIN_PASSWORD;
    if (!pass || req.headers.get("authorization") !== "Bearer " + pass)
      return new Response("Unauthorized", { status: 401 });
    const body = await req.json();
    if (typeof body !== "object" || Array.isArray(body) || JSON.stringify(body).length > 100000)
      return new Response("Bad request", { status: 400 });
    await store.setJSON("config", body);
    return Response.json({ ok: true });
  }
  return new Response("Method not allowed", { status: 405 });
};

export const config = { path: "/api/config" };
