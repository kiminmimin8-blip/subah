import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
import { createTx } from "../lib/tripay.mjs";
import { loadRanks, price } from "../lib/pricing.mjs";

const NAME = /^\.?[A-Za-z0-9_]{3,17}$/;
const json = (o, status = 200) => Response.json(o, { status, headers: { "cache-control": "no-store" } });

export default async (req) => {
  const url = new URL(req.url);
  const store = getStore("orders");

  // Cek status order (id acak, hanya status yang dibuka)
  if (url.pathname === "/api/order-status" && req.method === "GET") {
    const id = url.searchParams.get("id") || "";
    if (!/^[A-Z0-9]{6,20}$/.test(id)) return json({ error: "id tidak valid" }, 400);
    for (const [p, s] of [["done/", "DELIVERED"], ["paid/", "PAID"], ["pending/", "UNPAID"], ["closed/", null]]) {
      const o = await store.get(p + id, { type: "json" });
      if (o) return json({ status: s || o.status });
    }
    return json({ status: "NOT_FOUND" }, 404);
  }

  // Buat order + QR pembayaran
  if (url.pathname === "/api/order" && req.method === "POST") {
    const b = await req.json().catch(() => ({}));
    if (!NAME.test(b.username || "")) return json({ error: "Username Minecraft tidak valid" }, 400);
    const cfg = (await getStore("sanz").get("config", { type: "json" })) || {};
    const p = price(b.rank, cfg, await loadRanks(url.origin));
    if (!p) return json({ error: "Rank tidak tersedia" }, 400);

    const id = crypto.randomBytes(5).toString("hex").toUpperCase();
    let tx;
    try {
      tx = await createTx({
        ref: id,
        amount: p.amount,
        name: b.username,
        items: [{ name: "Rank " + p.name + " - Sanz Gen 2", price: p.amount, quantity: 1 }],
        callbackUrl: url.origin + "/api/tripay-callback",
        returnUrl: url.origin,
      });
    } catch (e) {
      console.error("Tripay create gagal:", e.message);
      return json({ error: "Gagal membuat pembayaran. Coba lagi sebentar." }, 502);
    }
    await store.setJSON("pending/" + id, {
      id, username: b.username, rank: p.name, amount: p.amount,
      reference: tx.reference, status: "UNPAID", ts: Date.now(),
    });
    return json({
      id, amount: tx.amount || p.amount, qr_string: tx.qr_string, qr_url: tx.qr_url,
      checkout_url: tx.checkout_url, expired_time: tx.expired_time,
    });
  }
  return json({ error: "Not found" }, 404);
};

export const config = { path: ["/api/order", "/api/order-status"] };
