import { getStore } from "@netlify/blobs";

const ID = /^[A-Za-z0-9_-]{1,40}$/;

export default async (req) => {
  const path = new URL(req.url).pathname.replace(/\/+$/, "");
  const store = getStore("orders");
  const auth = req.headers.get("authorization") || "";
  const isPlugin = !!process.env.PLUGIN_KEY && auth === "Bearer " + process.env.PLUGIN_KEY;
  const isAdmin = !!process.env.ADMIN_PASSWORD && auth === "Bearer " + process.env.ADMIN_PASSWORD;

  // Admin: buat order tes yang langsung berstatus lunas
  if (path === "/api/plugin/test-order" && req.method === "POST") {
    if (!isAdmin) return new Response("Unauthorized", { status: 401 });
    const b = await req.json().catch(() => ({}));
    if (!/^\.?[A-Za-z0-9_]{3,17}$/.test(b.username || "") || !/^[A-Za-z0-9_ -]{2,30}$/.test(b.rank || ""))
      return new Response("Bad request", { status: 400 });
    const id = "T" + Date.now().toString(36).toUpperCase();
    await store.setJSON("paid/" + id, { id, username: b.username, rank: b.rank, ts: Date.now() });
    return Response.json({ ok: true, id });
  }

  if (!isPlugin) return new Response("Unauthorized", { status: 401 });

  // Plugin: ambil order lunas yang belum dikirim
  if (path === "/api/plugin/orders" && req.method === "GET") {
    const { blobs } = await store.list({ prefix: "paid/" });
    const out = [];
    for (const b of blobs.slice(0, 50)) {
      const o = await store.get(b.key, { type: "json" });
      if (o) out.push(o);
    }
    return Response.json(out, { headers: { "cache-control": "no-store" } });
  }

  // Plugin: tandai sudah dikirim
  const m = path.match(/^\/api\/plugin\/orders\/([^/]+)\/delivered$/);
  if (m && req.method === "POST") {
    const id = decodeURIComponent(m[1]);
    if (!ID.test(id)) return new Response("Bad request", { status: 400 });
    const o = await store.get("paid/" + id, { type: "json" });
    if (o) {
      await store.setJSON("done/" + id, { ...o, deliveredAt: Date.now() });
      await store.delete("paid/" + id);
    }
    return Response.json({ ok: true });
  }
  return new Response("Not found", { status: 404 });
};

export const config = { path: ["/api/plugin/orders", "/api/plugin/orders/*", "/api/plugin/test-order"] };
