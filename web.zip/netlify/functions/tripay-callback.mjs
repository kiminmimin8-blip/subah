import { getStore } from "@netlify/blobs";
import { sign, safeEq } from "../lib/tripay.mjs";

const ok = (o) => Response.json(o);

export default async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const raw = await req.text(); // signature dihitung dari body mentah
  const sig = req.headers.get("x-callback-signature") || "";
  if (!process.env.TRIPAY_PRIVATE_KEY || !safeEq(sig, sign(raw)))
    return Response.json({ success: false, message: "Invalid signature" }, { status: 401 });
  if (req.headers.get("x-callback-event") !== "payment_status")
    return ok({ success: false, message: "Unrecognized event" });

  let d;
  try { d = JSON.parse(raw); } catch { return ok({ success: false, message: "Invalid JSON" }); }
  const id = String(d.merchant_ref || "");
  if (!/^[A-Za-z0-9_-]{1,40}$/.test(id)) return ok({ success: false, message: "Bad ref" });

  const store = getStore("orders");
  if ((await store.get("paid/" + id)) || (await store.get("done/" + id))) return ok({ success: true }); // sudah diproses
  const o = await store.get("pending/" + id, { type: "json" });
  if (!o) return ok({ success: false, message: "Order not found" });
  if (String(d.reference) !== String(o.reference)) return ok({ success: false, message: "Reference mismatch" });

  const st = String(d.status).toUpperCase();
  if (st === "PAID") {
    if (Number(d.total_amount) < o.amount) return ok({ success: false, message: "Amount mismatch" });
    // bentuk ini yang dibaca plugin SanzRank
    await store.setJSON("paid/" + id, {
      id, username: o.username, rank: o.rank, amount: o.amount, reference: o.reference, ts: Date.now(),
    });
    await store.delete("pending/" + id);
  } else if (st === "EXPIRED" || st === "FAILED") {
    await store.setJSON("closed/" + id, { ...o, status: st, ts: Date.now() });
    await store.delete("pending/" + id);
  } else {
    return ok({ success: false, message: "Unrecognized status" });
  }
  return ok({ success: true });
};

export const config = { path: "/api/tripay-callback" };
