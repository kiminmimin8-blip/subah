var CFG={};
function applyCfg(c){CFG=c||{};var d=CFG.discount,R=CFG.ranks||{};
 RANKS=RANKS.filter(function(r){return !(R[r.n]&&R[r.n].off)});
 RANKS.forEach(function(r){var o=R[r.n]||{};
  ["home","pv","pw","kit"].forEach(function(k){if(o[k])r[k]=o[k]});
  if(o.cmd&&o.cmd.length)r.cmd=o.cmd;
  if(!r.custom){if(o.old)r.old=+o.old;if(typeof d==="number")r.now=Math.round(r.old*(100-d)/100);if(o.now)r.now=+o.now}
 });
}
function boot(){
var STORE=CFG.store||"https://sanznewgen.net";
var $=function(i){return document.getElementById(i)};
var rp=function(n){return "Rp"+n.toLocaleString("id-ID")};
var esc=function(s){var d=document.createElement("div");d.textContent=s;return d.innerHTML};
var q=function(x){return document.querySelector(x)};
var bd=q(".badge");
if(bd){if(typeof CFG.discount==="number")bd.textContent="DISKON "+CFG.discount+"% SEMUA RANK";if(CFG.badge)bd.textContent=CFG.badge}
if(document.body.dataset.page==="home"){if(CFG.title)q("h1").innerHTML=esc(CFG.title).replace(/\n/g,"<br>");if(CFG.sub)q("header p").textContent=CFG.sub}
if(CFG.announce){var an=document.createElement("div");an.className="ann";an.textContent=CFG.announce;document.body.insertBefore(an,document.body.firstChild)}
var PROMO_END=CFG.promoEnd||"";
// hitung mundur
if(PROMO_END&&$("cd")){var end=new Date(PROMO_END).getTime(),cd=document.getElementById("cd");cd.style.display="flex";
 (function tick(){var t=Math.max(0,end-Date.now());
  $("d").textContent=Math.floor(t/864e5);$("h").textContent=Math.floor(t/36e5)%24;$("m").textContent=Math.floor(t/6e4)%60;$("sc").textContent=Math.floor(t/1e3)%60;
  if(t>0)setTimeout(tick,1000)})()}
// bintang
(function(){var c=document.getElementById("stars");if(!c)return;var x=c.getContext("2d"),S=[];
 function fit(){c.width=innerWidth;c.height=innerHeight;S=[];for(var i=0;i<70;i++)S.push({x:Math.random()*c.width,y:Math.random()*c.height,r:Math.random()*1.4+.3,p:Math.random()*6})}
 function draw(t){x.clearRect(0,0,c.width,c.height);S.forEach(function(s){x.globalAlpha=.35+.35*Math.sin(t/900+s.p);x.fillStyle="#fff";x.fillRect(s.x,s.y,s.r,s.r)});
  if(!matchMedia("(prefers-reduced-motion:reduce)").matches)requestAnimationFrame(draw)}
 fit();addEventListener("resize",fit);requestAnimationFrame(draw)})();

document.querySelectorAll('nav a[href^="https://sanznewgen"],footer a').forEach(function(a){a.href=STORE});
var L={};["discord","waGroup","waChannel","linktree"].forEach(function(k){L[k]=/^https:\/\//.test(CFG[k]||"")?CFG[k]:LINKS[k]});
L.customWa=/^62\d{8,13}$/.test(CFG.customWa||"")?CFG.customWa:LINKS.customWa;
if($("ranks")){
document.getElementById("ranks").innerHTML=RANKS.map(function(r,i){
  var price=r.custom?"":'<div class="old">'+rp(r.old)+'</div><div class="price">'+rp(r.now)+'</div><div class="save">Hemat '+rp(r.old-r.now)+'</div>';
  var tag=r.tag?'<div class="cmd">'+esc(r.tag)+'</div>':"";
  var rows=[["Home Limit",r.home],["PlayerVault",r.pv],["P-Warp Limit",r.pw]].map(function(x){return "<div><dt>"+x[0]+"</dt><dd>"+esc(x[1])+"</dd></div>"}).join("");
  var extra=(r.extra||[]).map(function(e){return '<div><dt>Bonus</dt><dd>'+esc(e)+'</dd></div>'}).join("");
  var cmds='<div class="cmd">Commands<br>'+r.cmd.map(function(c){return "<code>"+esc(c)+"</code>"}).join("")+"</div>";
  return '<article class="card'+(r.custom?" custom":"")+'" style="--c:'+r.c+'"><span class="glyph" aria-hidden="true">'+r.g+'</span><h2>'+esc(r.n)+'</h2>'+tag+price+
   '<dl>'+rows+extra+'</dl>'+cmds+'<div class="kit">Kits: '+esc(r.kit)+'</div>'+
   '<a class="btn buy" data-i="'+i+'" href="'+STORE+'" target="_blank" rel="noopener">'+(r.custom?"Pesan Custom":"Beli "+esc(r.n))+'</a></article>';
}).join("");

var mode="promo",view="cards",budget=0;
var pr=function(r){return mode==="promo"?r.now:r.old};
function render(){
  document.querySelectorAll("#ranks .card").forEach(function(el,i){
    var r=RANKS[i];if(r.custom)return;
    el.querySelector(".price").textContent=rp(pr(r));
    el.querySelector(".old").style.display=mode==="promo"?"":"none";
    el.querySelector(".save").style.display=mode==="promo"?"":"none";
    el.classList.toggle("dim",budget>0&&pr(r)>budget);
  });
  document.getElementById("bo").textContent=budget?rp(budget):"Semua";
  document.getElementById("ranks").style.display=view==="cards"?"":"none";
  document.getElementById("tbl").style.display=view==="table"?"block":"none";
  ["vc","vt","pp","pn"].forEach(function(id){var on=(id==="vc"&&view==="cards")||(id==="vt"&&view==="table")||(id==="pp"&&mode==="promo")||(id==="pn"&&mode==="normal");document.getElementById(id).setAttribute("aria-pressed",on)});
  var rows=[["Harga",function(r){return r.custom?"Via ticket Discord / WA":rp(pr(r))}],["Home Limit",function(r){return esc(r.home)}],["PlayerVault",function(r){return esc(r.pv)}],["P-Warp Limit",function(r){return esc(r.pw)}],["Commands",function(r){return r.cmd.map(function(c){return "<code>"+esc(c)+"</code>"}).join(" ")}],["Kits",function(r){return esc(r.kit)}]];
  document.getElementById("tbl").innerHTML="<table><thead><tr><th></th>"+RANKS.map(function(r){return '<th style="--c:'+r.c+'">'+r.g+" "+esc(r.n)+"</th>"}).join("")+"</tr></thead><tbody>"+rows.map(function(x){return "<tr><th>"+x[0]+"</th>"+RANKS.map(function(r){return "<td>"+x[1](r)+"</td>"}).join("")+"</tr>"}).join("")+"</tbody></table>";
}
document.getElementById("vc").onclick=function(){view="cards";render()};
document.getElementById("vt").onclick=function(){view="table";render()};
document.getElementById("pp").onclick=function(){mode="promo";render()};
document.getElementById("pn").onclick=function(){mode="normal";render()};
document.getElementById("bud").oninput=function(e){budget=+e.target.value;render()};
render();
var cur=null,oid="";
function waLink(t){return "https://wa.me/"+CFG.wa+"?text="+encodeURIComponent(t)}
var timer=null,NM=/^\.?[A-Za-z0-9_]{3,17}$/;
function gen(){var u=$("pu").value.trim(),box=$("pq"),b=$("pwa"),ok=NM.test(u);
 clearInterval(timer);$("ps").textContent="";
 if(CFG.pay==="tripay"){b.style.display="none";$("pgo").style.display="";$("pgo").disabled=!ok;
  box.innerHTML='<p class="hint">'+(ok?"Klik tombol di bawah untuk membuat QR pembayaran.":"Isi username Minecraft dulu (3-17 karakter: huruf, angka, _).")+"</p>";return}
 $("pgo").style.display="none";
 if(!ok){box.innerHTML='<p class="hint">Isi username Minecraft dulu untuk menampilkan QR.</p>';b.style.display="none";return}
 try{var qr=qrcode(0,"M");qr.addData(dynQris(CFG.qris,cur.now));qr.make();box.innerHTML='<div class="qr">'+qr.createSvgTag({cellSize:5,margin:0,scalable:true})+'</div>'}
 catch(x){box.textContent="QRIS belum valid, hubungi admin.";return}
 if(CFG.wa){b.style.display="";b.href=waLink("Halo admin, saya sudah bayar.\nOrder: "+oid+"\nRank: "+cur.n+"\nUsername: "+u+"\nTotal: "+rp(cur.now))}
}
function openPay(r){cur=r;oid="SANZ-"+Date.now().toString(36).toUpperCase().slice(-6);
 $("pt").textContent="Beli Rank "+r.n;$("pa").textContent="Total: "+rp(r.now);$("po").textContent=CFG.pay==="tripay"?"":"Order: "+oid;$("pu").value="";gen();$("pay").showModal()}
$("pu").oninput=gen;
$("pay").addEventListener("close",function(){clearInterval(timer)});
$("pgo").onclick=function(){var u=$("pu").value.trim();$("pgo").disabled=true;$("ps").textContent="Membuat QR...";
 fetch("/api/order",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({username:u,rank:cur.n})})
 .then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||"Gagal membuat order");return j})})
 .then(function(j){var box=$("pq");$("po").textContent="Order: "+j.id;$("pa").textContent="Total: "+rp(j.amount);
  if(j.qr_string){var qr=qrcode(0,"M");qr.addData(j.qr_string);qr.make();box.innerHTML='<div class="qr">'+qr.createSvgTag({cellSize:5,margin:0,scalable:true})+'</div>'}
  else if(j.qr_url){var d=document.createElement("div");d.className="qr";var im=new Image();im.alt="QR pembayaran";im.src=j.qr_url;im.style.width="100%";d.appendChild(im);box.innerHTML="";box.appendChild(d)}
  else if(j.checkout_url){box.innerHTML="";var a=document.createElement("a");a.className="btn";a.target="_blank";a.rel="noopener";a.href=j.checkout_url;a.textContent="Buka halaman pembayaran";box.appendChild(a)}
  $("ps").textContent="Menunggu pembayaran...";
  timer=setInterval(function(){fetch("/api/order-status?id="+encodeURIComponent(j.id)).then(function(r){return r.json()}).then(function(x){
   if(x.status==="PAID"||x.status==="DELIVERED"){clearInterval(timer);$("ps").textContent="Pembayaran diterima! Rank dipasang otomatis saat kamu online di server."}
   else if(x.status==="EXPIRED"||x.status==="FAILED"){clearInterval(timer);$("ps").textContent=(x.status==="EXPIRED"?"QR kedaluwarsa":"Pembayaran gagal")+". Tutup lalu buat order baru."}
  }).catch(function(){})},4000)})
 .catch(function(e){$("ps").textContent=e.message;$("pgo").disabled=false})};
$("ranks").addEventListener("click",function(e){var a=e.target.closest(".buy");if(!a)return;var r=RANKS[+a.dataset.i];
 if(r.custom){if(CFG.wa){e.preventDefault();window.open(waLink("Halo admin, saya mau pesan Custom Rank di Sanz Gen 2"),"_blank")}return}
 if(CFG.pay==="tripay"||CFG.qris){e.preventDefault();openPay(r)}});
var cc=document.querySelector(".card.custom");
if(cc){var bt=cc.querySelector(".buy"),bx=document.createElement("div"),num="0"+L.customWa.replace(/^62/,"");
 bx.innerHTML='<p class="hint" style="text-align:left">Custom Rank dipesan lewat admin, tidak dibeli otomatis. Buat <b>ticket di Discord</b> atau chat WhatsApp <b>'+num+'</b>.</p><div class="row2"><a class="btn" href="'+L.discord+'" target="_blank" rel="noopener">Buat Ticket Discord</a><a class="btn" href="'+waLink("Halo admin, saya mau pesan Custom Rank di Sanz Gen 2").replace("https://wa.me/"+CFG.wa,"https://wa.me/"+L.customWa)+'" target="_blank" rel="noopener">Chat WhatsApp</a></div>';
 bt.replaceWith(bx)}
}
if($("feat"))$("feat").innerHTML=FEATURES.map(function(f){return "<div><b>"+esc(f.t)+"</b><span>"+esc(f.d)+"</span></div>"}).join("");
if($("rules"))$("rules").innerHTML=RULES.map(function(x){return "<li>"+esc(x)+"</li>"}).join("");
if($("links"))$("links").innerHTML=[["Discord",L.discord,"dc"],["Grup WhatsApp",L.waGroup,"wa"],["Channel WhatsApp",L.waChannel,"wa"],["Semua link (Linktree)",L.linktree,""]].map(function(x){return '<a class="'+x[2]+'" href="'+x[1]+'" target="_blank" rel="noopener">'+x[0]+"</a>"}).join("");
}
fetch("/api/config").then(function(r){return r.ok?r.json():{}}).catch(function(){return {}}).then(function(c){applyCfg(c);boot()});
