// ====== EDIT DATA RANK DI SINI ======
// Tambah fitur: masukkan ke array "extra" (muncul sebagai baris tambahan).
var RANKS = [
 {n:"Aries",g:"♈",c:"#ff6b5e",old:10000,now:8000,home:"5",pv:"1",pw:"2",cmd:["/stonecutter","/wb"],kit:"Aries Kits",extra:[]},
 {n:"Taurus",g:"♉",c:"#7bd88f",old:20000,now:16000,home:"10",pv:"3",pw:"3",cmd:["/ec","/wb","/stonecutter"],kit:"Aries Kits",extra:[]},
 {n:"Gemini",g:"♊",c:"#ffd45e",old:40000,now:32000,home:"15",pv:"6",pw:"5",cmd:["/ec","/trash","/stonecutter","/grindstone","/wb"],kit:"Gemini Kits",extra:[]},
 {n:"Cancer",g:"♋",c:"#8fd3ff",old:70000,now:56000,home:"25",pv:"10",pw:"10",cmd:["/feed","/anvil","/repair","/recipe"],kit:"Cancer Kits",extra:[]},
 {n:"Leo",g:"♌",c:"#ffa347",old:120000,now:96000,home:"50",pv:"20",pw:"20",cmd:["/pweather","/ptime","/nick","/hat"],kit:"Leo Kits",extra:[]},
 {n:"Virgo",g:"♍",c:"#c9a7ff",old:200000,now:160000,home:"100",pv:"40",pw:"50",cmd:["/msgtoggle","/repairall"],kit:"Virgo Kits",extra:[]},
 {n:"Libra",g:"♎",c:"#ff8fc7",old:300000,now:240000,home:"500",pv:"75",pw:"100",cmd:["/tptoggle","/invsee","/weather","/time"],kit:"Libra Kits",extra:[]},
 {n:"Scorpio",g:"♏",c:"#ff4d6d",old:400000,now:320000,home:"Unlimited",pv:"100",pw:"Unlimited",cmd:["/god","/vanish"],kit:"Universe Ultimate Kits",extra:["Termasuk semua fitur rank sebelumnya"],tag:"The Ultimate Zodiac"},
 {n:"Custom Rank",g:"♾",c:"#5ee0c1",custom:true,home:"Unlimited",pv:"150",pw:"Unlimited",cmd:["/god","All Commands"],kit:"Semua Kit Rank",extra:["Rank paling OP, tampil beda dari yang lain"]}
];
// ====================================

// ---- QRIS dinamis: ubah QRIS statis jadi QRIS dengan nominal ----
function crc16(t){var c=0xFFFF;for(var i=0;i<t.length;i++){c^=t.charCodeAt(i)<<8;for(var j=0;j<8;j++)c=(c&0x8000)?((c<<1)^0x1021):(c<<1);c&=0xFFFF}return c.toString(16).toUpperCase().padStart(4,"0")}
function dynQris(q,amt){
  q=q.trim();q=q.slice(0,-4);               // buang CRC lama (sisa "6304")
  q=q.replace("010211","010212");           // statis -> dinamis
  q=q.replace(/54\d\d\d+(?=5802ID)/,"");    // buang nominal lama kalau ada
  var a=String(Math.round(amt)),t="54"+String(a.length).padStart(2,"0")+a,i=q.indexOf("5802ID");
  if(i<0)throw new Error("QRIS tidak valid");
  q=q.slice(0,i)+t+q.slice(i);
  return q+crc16(q);
}

// ---- Link komunitas (bisa ditimpa dari admin) ----
var LINKS={
  discord:"https://discord.gg/AfstekBJch",
  waGroup:"https://chat.whatsapp.com/Hg8bMXHPg3r5rVztLCh2AE",
  waChannel:"https://whatsapp.com/channel/0029Vb8lKHG1NCrbnIC0pT0Q",
  linktree:"https://linktr.ee/sanznewgen2",
  customWa:"6285385111814" // format 62..., tujuan chat pesan Custom Rank
};
// ---- Daftar fitur server (edit di sini) ----
var FEATURES=[
 {t:"Survival Economy",d:"Survival dengan sistem ekonomi: kumpulkan uang, belanja, dan berkembang bersama pemain lain di Minecraft Java Edition."},
 {t:"Java dan Bedrock",d:"Bisa main dari PC (Java) maupun HP (Bedrock) lewat cross-play."},
 {t:"Dungeon dan boss",d:"Dungeon berlevel dengan boss, minion, dan hadiah untuk pemain yang berhasil menamatkannya."},
 {t:"Custom mob dan item",d:"Mob buatan sendiri dengan item berrarity Umum, Langka, Epik, dan Legendaris."},
 {t:"Bot dan NPC tarung",d:"NPC petarung untuk latihan combat tanpa harus menunggu lawan."},
 {t:"Home, PlayerVault, P-Warp",d:"Simpan rumah, brankas item pribadi, dan warp milikmu sendiri. Jumlahnya naik sesuai rank."},
 {t:"Rank Zodiac",d:"Delapan rank dari Aries sampai Scorpio dengan command dan kit eksklusif."},
 {t:"Anti-cheat aktif",d:"Server dipantau anti-cheat dan staff supaya permainan tetap adil."}
];
// ---- Aturan (dari aturan komunitas Sanz) ----
var RULES=[
 "Dilarang promosi server atau website luar.",
 "Dilarang mengirim stiker atau membahas konten 18+.",
 "Dilarang memanfaatkan bug.",
 "Dilarang rasisme terhadap agama dan ras.",
 "Dilarang menyebarkan website atau link luar.",
 "Dilarang spam berlebihan.",
 "Dilarang grief tanpa kepastian atau ketentuan.",
 "Toxic boleh, tapi jangan berlebihan. Kalau berlebihan akan kena sanksi.",
 "Dan peraturan lain yang berlaku di server."
];
